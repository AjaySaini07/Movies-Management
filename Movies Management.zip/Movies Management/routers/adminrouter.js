const router = require('express').Router()
const registerContro = require('../controllers/registercontroler')
const categoryContro = require('../controllers/categorycontroler')
const movieContro = require('../controllers/moviecontroler')
const upload = require('../helper/multer')


router.get('/login', registerContro.loginform)
router.post('/login', registerContro.logincheck)
router.get('/dashboard',registerContro.dashboard)
router.get('/logout', registerContro.logout)

router.get('/categoryshow/:mess', categoryContro.categoryShow)
router.get('/addcategory', categoryContro.categoryaddForm)
router.post('/addcategory', categoryContro.categoryAdd)
router.get('/categorydelete/:id', categoryContro.categoryDelete)

router.get('/movieshow/:mess', movieContro.movieShow)
router.get('/addmovie', movieContro.movieaddForm)
router.post('/addmovie', upload.single('img'), movieContro.movieAdd)
router.get('/moviedelete/:id', movieContro.movieDelete)
router.get('/statusupdate/:id', movieContro.statusUpdate)







module.exports = router