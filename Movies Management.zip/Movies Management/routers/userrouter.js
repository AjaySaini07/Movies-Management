const router = require('express').Router()
const registerContro = require('../controllers/registercontroler')
const categoryContro = require('../controllers/categorycontroler')
const movieContro = require('../controllers/moviecontroler')
const movieTable = require('../models/movietable')


router.get('/', async(req,res) => {
    const movieData = await movieTable.find({status:'Published'})
    //console.log(movieData)
    res.render('home.ejs', {movieData})
})









module.exports = router