const mongoose = require('mongoose')

const movieSchema = mongoose.Schema({
    img:{
        type:String,
        required:true
    },
    mname:{
        type:String,
        required:true
    },
    mdesc:{
        type:String,
        require:true
    },
    mcat:{
        type:String
    },
    postedDate:{
        type:Date,
        required:true,
        default:new Date()
    },
    status:{
        type:String,
        required:true,
        default:'Unpublished'
    }
})

module.exports = mongoose.model('movie', movieSchema)