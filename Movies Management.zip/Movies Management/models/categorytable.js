const mongoose = require('mongoose')

const catSchema = mongoose.Schema({
    catname:{
        type:String,
        required:true
    },
    postedDate:{
        type:Date,
        default:new Date(),
        required:true
    }
})

module.exports = mongoose.model('category', catSchema)