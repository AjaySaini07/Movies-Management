const registerTable = require('../models/registertable')
let message = ''

exports.dashboard = (req,res)=>{
    res.render('admin/dashboard.ejs')
}

exports.loginform = (req,res) => {
    res.render('admin/login.ejs', {message})
}

exports.logincheck = async(req,res) => {
    //console.log(req.body)
    let message = ''
    const{uname,passw} = req.body
    const userCheck = await registerTable.findOne({username:uname})
    //console.log(userCheck)
    if(userCheck != null) {
        if(userCheck.password == passw) {
            req.session.Auth = true
            //res.render('admin/dashboard.ejs')
            res.redirect('/admin/dashboard')
        } else {
            message = 'Invalid Password...!'
            res.render('admin/login.ejs', {message})
        }
    } else if(uname == '' && passw == '') {
        message = 'Please Fill Username & Password...!'
        res.render('admin/login.ejs', {message})
    } else {
        message = 'Invalid Username...!'
        res.render('admin/login.ejs', {message})
    }
    // res.render('admin/dashboard.ejs')
}

exports.logout = (req,res) => {
    req.session.destroy(),
    res.redirect('/admin/login')
}
