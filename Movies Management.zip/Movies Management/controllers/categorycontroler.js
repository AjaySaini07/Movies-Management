const categoryTable = require('../models/categorytable')

exports.categoryShow = async(req,res) => {
    //console.log(req.params.mess)
    const message = req.params.mess
    const data = await categoryTable.find()
    //console.log(data)
    res.render('admin/category.ejs', {data,message})    
}
exports.categoryaddForm = (req,res) => {
    res.render('admin/addcategory.ejs')
}
exports.categoryAdd = (req,res) => {
    //console.log(req.body)
    const{catname} = req.body
    const catData = new categoryTable({catname:catname})
    catData.save()
    res.redirect('/admin/categoryshow/Category has been successfully added...!')
}
exports.categoryDelete = async(req,res) => {
    console.log(req.params.id)
    const id = req.params.id
    await categoryTable.findByIdAndDelete(id)
    res.redirect('/admin/categoryshow/Category has been successfully deleted...!')
}