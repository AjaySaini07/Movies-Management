const movieTable = require('../models/movietable')
const categoryTable = require('../models/categorytable')
//const categoryTable = require('../models/categorytable')

exports.movieShow = async(req,res) => {
    //console.log(req.query)
    //console.log(req.params.mess)
    const message = req.params.mess
    if(req.params.mess == 'hit1') {
        var movieData = await movieTable.find().sort({postedDate:1})
    } else if (req.params.mess == 'hit2') {
        var movieData = await movieTable.find().sort({postedDate:-1})
    } else if(req.query.status!==undefined) {
        var movieData = await movieTable.find({status:req.query.status}).sort({postedDate:-1})
    } else if(req.query.status==undefined){
        var movieData = await movieTable.find().sort({postedDate:-1})
    }
    //console.log(movieData)
    const catData = await categoryTable.find()
    //console.log(catData)
    const totalCount = await movieTable.find().count()
    //console.log(totalCount)
    const pubCount = await movieTable.find({status:'Published'}).count()
    //console.log(pubCount)
    const unpubCount = await movieTable.find({status:'Unpublished'}).count()
    //console.log(unpubCount)
    res.render('admin/movie.ejs', {movieData,catData,totalCount,pubCount,unpubCount,message})
}
exports.movieaddForm = async(req,res) => {
    const{catname} = req.body
    const catData = await categoryTable.find({mcategory:catname})
    //console.log(catData)
    res.render('admin/addmovie.ejs', {catData})
}
exports.movieAdd = (req,res) => {
    //console.log(req.body)
    //console.log(req.file)
    //const imgName = req.file.filename
    const{mname,mdesc,mcategory,img} = req.body
    const movieData = new movieTable({mname:mname, mdesc:mdesc, mcat:mcategory, img:req.file.filename})
    movieData.save()
    res.redirect('/admin/movieshow/Movie has been successfully Added...!') 
}
exports.movieDelete = async(req,res) => {
    //console.log(req.params.id)
    const id = req.params.id
    await movieTable.findByIdAndDelete(id)
    res.redirect('/admin/movieshow/Movie has been successfully deleted...!')     
}
exports.statusUpdate = async(req,res) => {
    //console.log(req.params.id)
    const id = req.params.id
    const data = await movieTable.findById(id)
    //console.log(data)
    let newStatus = null
    if(data.status == 'Unpublished') {
        newStatus = 'Published'
    } else {
        newStatus = 'Unpublished'
    }
    await movieTable.findByIdAndUpdate(id, {status:newStatus})
    res.redirect('/admin/movieshow/kk')
}