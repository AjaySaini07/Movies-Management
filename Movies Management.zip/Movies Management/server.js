console.log('Jai Saraswati Maa')
const express = require('express')
const server = express()
const mongoose = require('mongoose')
mongoose.connect('mongodb://127.0.0.1:27017/project3').then(()=>{console.log('Connected to DB(Project3)...!')}).catch((error)=>{console.log(error.message)})
server.use(express.urlencoded({extended:false}))
const session = require('express-session')
const userRouter = require('./routers/userrouter')
const adminRouter = require('./routers/adminrouter')




server.use(session({
    secret:'krishna',
    resave:false,
    saveUninitialized:false
}))
server.use(userRouter)
server.use('/admin', adminRouter)
server.use(express.static('public'))
server.set('view engine', 'ejs')
server.listen(5000, ()=> {console.log('Server is running on port 5000')})